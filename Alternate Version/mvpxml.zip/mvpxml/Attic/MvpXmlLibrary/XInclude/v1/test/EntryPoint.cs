using System;

namespace Mvp.Xml.XInclude.Test
{
    /// <summary>
    /// Entry point for console application.
    /// </summary>
    public class EntryPoint
    {
        public static void Main() 
        {            
            //XIncludeReaderTests rt = new XIncludeReaderTests();
            //LTG_Edinburgh_UnivTests rt = new LTG_Edinburgh_UnivTests();
            NISTTests rt = new NISTTests();
            //Elliotte_Rusty_HaroldTests rt = new Elliotte_Rusty_HaroldTests();
            //FourThoughtTests rt = new FourThoughtTests();
            //XIncludeSyntaxTests rt = new XIncludeSyntaxTests();
            try 
            {                
                rt.Nist_include_24();
            } 
            catch (Exception e) 
            {
                Console.WriteLine(e);
            }
        }
    }
}
