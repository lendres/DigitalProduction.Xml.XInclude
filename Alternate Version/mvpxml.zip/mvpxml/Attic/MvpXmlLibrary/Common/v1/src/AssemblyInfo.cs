using System;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Security.Permissions;

[assembly: ComVisible(false)]
[assembly: CLSCompliant(true)]

[assembly: AssemblyTitle("Mvp.Xml.Common")]
[assembly: AssemblyDescription("MVP XML Library - Common Module")]
[assembly: AssemblyVersion("1.0.*")]

[assembly: AssemblyDelaySign(false)]
[assembly: AssemblyKeyFile("../../../../../Global/mvp-xml.snk")]
[assembly: AssemblyKeyName("")]

#region Security Permissions

//[assembly: SecurityPermission(SecurityAction.RequestRefuse, UnmanagedCode=true)]

#endregion Security Permissions
