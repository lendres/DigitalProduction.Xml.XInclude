using System;
using System.Collections.Generic;
using System.Text;

namespace Mvp.Xml.Tests
{
	public class XmlWrappingReaderTests
	{
	}
}
